package com.kh.spring.detail.model.dao;

import java.util.List;

import com.kh.spring.art.model.vo.Art;

public interface DetailDAO {

	Art selectArtOne(String artId);

}
