package com.kh.spring.detail.model.service;

import java.util.List;

import com.kh.spring.art.model.vo.Art;

public interface DetailService {

	Art selectArtOne(String artId);

}
