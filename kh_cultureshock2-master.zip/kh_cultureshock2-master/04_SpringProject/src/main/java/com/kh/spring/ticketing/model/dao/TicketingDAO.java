package com.kh.spring.ticketing.model.dao;

import java.util.List;

import com.kh.spring.art.model.vo.Art;

public interface TicketingDAO {

	Art selectArtOne(String artId);

}
